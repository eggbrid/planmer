package kirito.peoject.constantlibs.net;

/**
 * @Description:
 * @Author:kirito
 * @CreatTime:2019/2/27 0027
 * @LastChekedBy: kirito
 */
public class HttpUrls {
    public final static String API_URL="http://www.shprochina.com/";

}
