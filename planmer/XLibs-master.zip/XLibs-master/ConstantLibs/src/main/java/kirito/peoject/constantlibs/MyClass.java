package kirito.peoject.constantlibs;

public class MyClass {
}
