package kirito.peoject.constantlibs.UIConstant.activity;

/**
 * @Description: In this class, you need to write the path of the activity in all baselib as a constant.
 * @Author:kirito
 * @CreatTime:2019/2/26 0026
 * @LastChekedBy: kirito
 * @needingAttention:Naming rules： module name / package name / class name
 */
public class BaseLibsActivitys {

}
