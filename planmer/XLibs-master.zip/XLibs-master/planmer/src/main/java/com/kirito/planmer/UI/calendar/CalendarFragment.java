package com.kirito.planmer.UI.calendar;

import kirito.peoject.baselib.UI.BaseFragment;

/**
 * @auther kirito
 * @Date 2019-05-20
 * @NOTE 日历类
 */
public class CalendarFragment extends BaseFragment<CalendarFragmentView> {
    @Override
    public void afterInitView(CalendarFragmentView view) {

    }



}
