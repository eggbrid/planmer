package com.kirito.planmer.UI.calendar;

import android.support.v7.app.AppCompatActivity;
import kirito.peoject.baselib.mvp.BaseV;

/**
 * @auther kirito
 * @Date 2019-05-20
 * @NOTE 类说明
 */
public class CalendarFragmentView extends BaseV {
    public CalendarFragmentView(AppCompatActivity activity) {
        super(activity);
    }

    @Override
    public int setViewLayout() {
        return 0;
    }

    @Override
    public void initView() {

    }
}
